import './Sobre.css'

const Sobre = () => {
    return (
        <h1>Sobre Nós</h1>
    )
}
export default Sobre