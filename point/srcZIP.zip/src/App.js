
import './App.css'
import RouterApp from './router';

function App() {
  return (
    <div className="app">
      <RouterApp/>
    </div>
  );
}

export default App;
